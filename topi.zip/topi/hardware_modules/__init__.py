from ADC import ADC
from ClockSwitch import ClockSwitch
from ClockSynth import ClockSynth