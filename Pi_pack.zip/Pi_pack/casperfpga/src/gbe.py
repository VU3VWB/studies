import logging

LOGGER = logging.getLogger(__name__)


class Gbe(object):
    """
    A (multi)gigabit network interface on a device. 
    """
    pass
